
const pool = require("../config/db");

const INDICADORES_VALIDOS = [
  "peso_edad",
  "talla_edad",
  "peso_talla",
  "perimetro_cefalico",
];

async function buscarReferenciaOMS({
  indicador,
  sexo,
  edadMeses,
  medidaCm,
}) {
  if (!INDICADORES_VALIDOS.includes(indicador)) {
    throw new Error("Indicador de crecimiento no válido");
  }

  if (!["masculino", "femenino"].includes(sexo)) {
    throw new Error("Sexo no válido");
  }

  const esPesoTalla = indicador === "peso_talla";
  const valorBuscado = esPesoTalla ? Number(medidaCm) : Number(edadMeses);

  if (!Number.isFinite(valorBuscado) || valorBuscado < 0) {
    throw new Error("Edad o medida inválida");
  }

  const sql = `
    SELECT
      r.id_referencia,
      r.indicador,
      r.sexo,
      r.archivo_origen,
      r.version_referencia,
      v.id_valor,
      v.edad_meses,
      v.medida_cm,
      v.l,
      v.m,
      v.s,
      v.sd3neg,
      v.sd2neg,
      v.sd1neg,
      v.sd0,
      v.sd1,
      v.sd2,
      v.sd3,
      v.tipo_medicion
    FROM referencias_crecimiento r
    INNER JOIN valores_referencia_oms v
      ON v.id_referencia = r.id_referencia
    WHERE r.indicador = $1
      AND r.sexo = $2
      AND r.estado = TRUE
  `;

  const { rows } = await pool.query(sql, [indicador, sexo]);

  if (!rows.length) {
    throw new Error(
      `No existen referencias OMS para ${indicador} (${sexo})`
    );
  }

  const columna = esPesoTalla ? "medida_cm" : "edad_meses";

  // Agrupar registros por archivo de referencia
  const referencias = new Map();

  for (const fila of rows) {
    const llave = fila.id_referencia;

    if (!referencias.has(llave)) {
      referencias.set(llave, {
        id_referencia: fila.id_referencia,
        archivo_origen: fila.archivo_origen,
        version_referencia: fila.version_referencia,
        filas: [],
      });
    }

    referencias.get(llave).filas.push(fila);
  }

  // Calcular rango real de cada archivo
  const grupos = [...referencias.values()].map((referencia) => {
    const valores = referencia.filas
      .map((fila) => Number(fila[columna]))
      .filter(Number.isFinite);

    return {
      ...referencia,
      minimo: Math.min(...valores),
      maximo: Math.max(...valores),
    };
  });

  // Buscar archivos cuyo rango contenga el valor solicitado
  const gruposQueContienen = grupos.filter(
    (grupo) =>
      valorBuscado >= grupo.minimo &&
      valorBuscado <= grupo.maximo
  );

  let grupoSeleccionado;

  if (gruposQueContienen.length > 0) {
    // Si hay más de uno, elegir el rango más específico
    grupoSeleccionado = gruposQueContienen.sort(
      (a, b) => (a.maximo - a.minimo) - (b.maximo - b.minimo)
    )[0];
  } else {
    // Si el valor está fuera de todos los rangos,
    // seleccionar el archivo con el límite más cercano
    grupoSeleccionado = grupos.sort((a, b) => {
      const distanciaA = Math.min(
        Math.abs(valorBuscado - a.minimo),
        Math.abs(valorBuscado - a.maximo)
      );

      const distanciaB = Math.min(
        Math.abs(valorBuscado - b.minimo),
        Math.abs(valorBuscado - b.maximo)
      );

      return distanciaA - distanciaB;
    })[0];
  }

  // Buscar el registro más cercano dentro del archivo seleccionado
  const filaSeleccionada = grupoSeleccionado.filas.sort(
    (a, b) =>
      Math.abs(Number(a[columna]) - valorBuscado) -
      Math.abs(Number(b[columna]) - valorBuscado)
  )[0];

  return {
    ...filaSeleccionada,
    rango_referencia: {
      minimo: grupoSeleccionado.minimo,
      maximo: grupoSeleccionado.maximo,
    },
  };
}

module.exports = { buscarReferenciaOMS };
