
const { buscarReferenciaOMS } = require("./referenciasOms");
const { calcularZOMS } = require("./calculadorOms");

async function evaluarCrecimientoOMS({
  indicador,
  sexo,
  edadMeses,
  pesoKg,
  tallaCm,
  perimetroCefalicoCm,
}) {
  let x;
  let medidaReferencia;

  switch (indicador) {
    case "peso_edad":
      x = Number(pesoKg);
      medidaReferencia = { edadMeses };
      break;

    case "talla_edad":
      x = Number(tallaCm);
      medidaReferencia = { edadMeses };
      break;

    case "peso_talla":
      x = Number(pesoKg);
      medidaReferencia = { medidaCm: tallaCm };
      break;

    case "perimetro_cefalico":
      x = Number(perimetroCefalicoCm);
      medidaReferencia = { edadMeses };
      break;

    default:
      throw new Error("Indicador de crecimiento no válido");
  }

  if (!Number.isFinite(x) || x <= 0) {
    throw new Error("La medición del indicador es inválida");
  }

  const referencia = await buscarReferenciaOMS({
    indicador,
    sexo,
    ...medidaReferencia,
  });

  const z = calcularZOMS({
    x,
    l: referencia.l,
    m: referencia.m,
    s: referencia.s,
  });

  return {
    indicador,
    sexo,
    edadMeses: edadMeses ?? null,
    medicion: x,
    unidad:
      indicador === "peso_edad" || indicador === "peso_talla"
        ? "kg"
        : "cm",
    puntuacion_z: z,
    referencia: {
      archivo: referencia.archivo_origen,
      version: referencia.version_referencia,
      l: referencia.l,
      m: referencia.m,
      s: referencia.s,
      edadReferencia: referencia.edad_meses,
      medidaReferencia: referencia.medida_cm,
      rango: referencia.rango_referencia,
    },
  };
}

module.exports = { evaluarCrecimientoOMS };
