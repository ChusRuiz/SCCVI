const pool = require("../config/db");
const { evaluarCrecimientoOMS } = require("../services/evaluarCrecimientoOms");



const registrarControl = async (req, res) => {
  try {
    const {
      id_paciente,
      fecha_control,
      peso_kg,
      talla_cm,
      perimetro_cefalico_cm,
      observaciones,
    } = req.body;

    if (!id_paciente || peso_kg == null || talla_cm == null) {
      return res.status(400).json({
        mensaje: "Paciente, peso y talla son obligatorios",
      });
    }

    const peso = Number(peso_kg);
    const talla = Number(talla_cm);
    const perimetro =
      perimetro_cefalico_cm == null || perimetro_cefalico_cm === ""
        ? null
        : Number(perimetro_cefalico_cm);

    if (
      !Number.isFinite(peso) ||
      !Number.isFinite(talla) ||
      peso <= 0 ||
      talla <= 0
    ) {
      return res.status(400).json({
        mensaje: "El peso y la talla deben ser valores válidos mayores a cero",
      });
    }

    if (perimetro !== null && (!Number.isFinite(perimetro) || perimetro <= 0)) {
      return res.status(400).json({
        mensaje: "El perímetro cefálico debe ser mayor a cero",
      });
    }

    const fecha = fecha_control || new Date().toISOString().slice(0, 10);

    const pacienteResult = await pool.query(
      `SELECT id_paciente, fecha_nacimiento, sexo
       FROM pacientes
       WHERE id_paciente = $1 AND estado = 'activo'`,
      [id_paciente]
    );

    if (pacienteResult.rows.length === 0) {
      return res.status(404).json({
        mensaje: "Paciente no encontrado o inactivo",
      });
    }

    const paciente = pacienteResult.rows[0];

    // Calcular edad en meses al momento del control
    const nacimiento = new Date(`${paciente.fecha_nacimiento.toISOString?.().slice(0, 10) || paciente.fecha_nacimiento}T00:00:00`);
    const fechaReferencia = new Date(`${fecha}T00:00:00`);

    if (
      Number.isNaN(nacimiento.getTime()) ||
      Number.isNaN(fechaReferencia.getTime()) ||
      fechaReferencia < nacimiento
    ) {
      return res.status(400).json({
        mensaje: "La fecha del control no es válida",
      });
    }

    let años = fechaReferencia.getFullYear() - nacimiento.getFullYear();
    let meses = fechaReferencia.getMonth() - nacimiento.getMonth();
    let dias = fechaReferencia.getDate() - nacimiento.getDate();

    if (dias < 0) {
      meses--;
    }

    if (meses < 0) {
      años--;
      meses += 12;
    }

    const edadMeses = años * 12 + meses;

    // Evaluaciones OMS
    const evaluaciones = {};

    evaluaciones.peso_edad = await evaluarCrecimientoOMS({
      indicador: "peso_edad",
      sexo: paciente.sexo,
      edadMeses,
      pesoKg: peso,
    });

    evaluaciones.talla_edad = await evaluarCrecimientoOMS({
      indicador: "talla_edad",
      sexo: paciente.sexo,
      edadMeses,
      tallaCm: talla,
    });

    evaluaciones.peso_talla = await evaluarCrecimientoOMS({
      indicador: "peso_talla",
      sexo: paciente.sexo,
      edadMeses,
      pesoKg: peso,
      tallaCm: talla,
    });

    if (perimetro !== null) {
      evaluaciones.perimetro_cefalico = await evaluarCrecimientoOMS({
        indicador: "perimetro_cefalico",
        sexo: paciente.sexo,
        edadMeses,
        perimetroCefalicoCm: perimetro,
      });
    }

    // Registrar control
    const resultado = await pool.query(
      `INSERT INTO controles_crecimiento
      (id_paciente, id_usuario, fecha_control, peso_kg,
       talla_cm, perimetro_cefalico_cm, observaciones)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      RETURNING *`,
      [
        id_paciente,
        req.usuario.id,
        fecha,
        peso,
        talla,
        perimetro,
        observaciones || null,
      ]
    );

    res.status(201).json({
      mensaje: "Control registrado y evaluado con referencias OMS",
      control: resultado.rows[0],
      edad_meses: edadMeses,
      evaluaciones_oms: evaluaciones,
    });
  } catch (error) {
    console.error("Error al registrar control:", error);

    res.status(500).json({
      mensaje: "Error al registrar o evaluar el control de crecimiento",
      detalle: error.message,
    });
  }
};


// HISTORIAL DE CRECIMIENTO DE UN PACIENTE
const obtenerHistorial = async (req, res) => {
  try {
    const { id } = req.params;

    const resultado = await pool.query(
      `SELECT c.*, u.nombre AS usuario_registro
       FROM controles_crecimiento c
       LEFT JOIN usuarios u ON c.id_usuario = u.id_usuario
       WHERE c.id_paciente = $1
       ORDER BY c.fecha_control DESC, c.id_control DESC`,
      [id]
    );

    res.json(resultado.rows);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      mensaje: "Error al consultar historial de crecimiento",
    });
  }
};

// CONSULTAR UN CONTROL
const obtenerControl = async (req, res) => {
  try {
    const { id } = req.params;

    const resultado = await pool.query(
      `SELECT c.*, p.nombres, p.apellidos
       FROM controles_crecimiento c
       JOIN pacientes p ON c.id_paciente = p.id_paciente
       WHERE c.id_control = $1`,
      [id]
    );

    if (resultado.rows.length === 0) {
      return res.status(404).json({
        mensaje: "Control no encontrado",
      });
    }

    res.json(resultado.rows[0]);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      mensaje: "Error al consultar el control",
    });
  }
};

// ELIMINAR CONTROL
const eliminarControl = async (req, res) => {
  try {
    const { id } = req.params;

    const resultado = await pool.query(
      `DELETE FROM controles_crecimiento
       WHERE id_control = $1
       RETURNING id_control`,
      [id]
    );

    if (resultado.rows.length === 0) {
      return res.status(404).json({
        mensaje: "Control no encontrado",
      });
    }

    res.json({
      mensaje: "Control eliminado correctamente",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      mensaje: "Error al eliminar el control",
    });
  }
};

module.exports = {
  registrarControl,
  obtenerHistorial,
  obtenerControl,
  eliminarControl,
};