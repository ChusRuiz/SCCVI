
const { evaluarCrecimientoOMS } = require("../services/evaluarCrecimientoOms");

const pruebas = [
  {
    nombre: "Peso para la edad",
    datos: {
      indicador: "peso_edad",
      sexo: "masculino",
      edadMeses: 12,
      pesoKg: 9.5,
    },
  },
  {
    nombre: "Talla para la edad",
    datos: {
      indicador: "talla_edad",
      sexo: "femenino",
      edadMeses: 24,
      tallaCm: 85,
    },
  },
  {
    nombre: "Peso para la talla",
    datos: {
      indicador: "peso_talla",
      sexo: "masculino",
      edadMeses: 18,
      pesoKg: 9.5,
      tallaCm: 75,
    },
  },
  {
    nombre: "Perímetro cefálico para la edad",
    datos: {
      indicador: "perimetro_cefalico",
      sexo: "femenino",
      edadMeses: 36,
      perimetroCefalicoCm: 48,
    },
  },
];

async function ejecutarPruebas() {
  console.log("\n===== EVALUACIÓN INTEGRADA OMS =====\n");

  for (const prueba of pruebas) {
    try {
      const resultado = await evaluarCrecimientoOMS(prueba.datos);

      console.log(`✓ ${prueba.nombre}`);
      console.log(`  Indicador: ${resultado.indicador}`);
      console.log(`  Sexo: ${resultado.sexo}`);
      console.log(`  Medición: ${resultado.medicion} ${resultado.unidad}`);
      console.log(`  Puntuación Z: ${resultado.puntuacion_z}`);
      console.log(`  Referencia: ${resultado.referencia.archivo}`);
      console.log(`  L: ${resultado.referencia.l}`);
      console.log(`  M: ${resultado.referencia.m}`);
      console.log(`  S: ${resultado.referencia.s}`);
      console.log("--------------------------------------\n");
    } catch (error) {
      console.error(`✗ ${prueba.nombre}`);
      console.error(`  Error: ${error.message}\n`);
    }
  }

  console.log("===== PRUEBAS FINALIZADAS =====");
  process.exit();
}

ejecutarPruebas();
